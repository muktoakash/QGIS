CITY_GREEN_SPACE_WGS84_readme
 

Column name  (Description)
======================================
GEO_ID = AREA_ID  (Unique geographic identifier)
TYPE_DESC = AREA_TYPE  (AREA_TYPE)
SCODE_NAME = AREA_SHORT_CODE  (AREA_SHORT_CODE)
LCODE_NAME = AREA_LONG_CODE  (Park Number)
NAME = AREA_NAME  (Park Name)
OBJECTID = OBJECTID  (Unique system identifier)
