NEIGHBOURHOODS_readme
 

Column name  (Description)
======================================
AREA_CODE = AREA_SHORT_CODE
AREA_NAME = AREA_NAME
