BICYCLE_SHOP_WGS84_readme
 

Column name  (Description)
======================================
ADDRESS = ADDRESS_FULL  (Bicycle Shop address)
POSTAL_CD = POSTAL_CODE  (Bicycle Shop postal code)
X = X  (Easting in MTM NAD27 3 degree Projection)
Y = Y  (Northing in MTM NAD27 3 degree Projection)
LONGITUDE = LONGITUDE  (Longitude in WGS84 Coordinate System)
LATITUDE = LATITUDE  (Latitude in WGS84 Coordinate System)
NAME = NAME  (Bicycle Shop email address)
UNIT = UNIT  (Bicycle Shop unit number (if applicable))
PHONE = PHONE  (PHONE)
EMAIL = EMAIL  (Bicycle Shop email address)
RENTAL = RENTAL  (Can bicycles be rented at the bicycle shop)
OBJECTID = OBJECTID  (Unique system identifier)
